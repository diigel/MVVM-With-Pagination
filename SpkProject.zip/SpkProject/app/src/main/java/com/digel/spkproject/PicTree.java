package com.digel.spkproject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.InputType;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


public class PicTree extends ActionBarActivity
{
    Node node = null;
    final Context context = this;
    boolean deletePressed = false;
    Node parentNode = null;
    int n = 10;
    Node root;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    List<Node> tree1= new ArrayList<Node>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pic_tree);
        try {
            serializeTree(null,"serializable.ser");
        } catch (IOException e2)
        {
            e2.printStackTrace();
        }
        try {

            root = deSerializeTree("serializable.ser");
            if(root!=null){
                showLevel(root);

            }
            else root=new Node("root",null);

        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        Button addButton= (Button) findViewById(R.id.addButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(PicTree.this);
                builder.setTitle("Add Node");
                final EditText input = new EditText(PicTree.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT );
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        final LinearLayout layoutTree = (LinearLayout) findViewById(R.id.treeLayout);
                        String buttonText;
                        final Button btn1 = new Button(context);
                        String nodeName = input.getText().toString();
                        if (parentNode == null)
                            parentNode = root;

                        final Node newNode = new Node(nodeName, parentNode);
                        parentNode.addChild(newNode);
                        Toast.makeText(PicTree.this, parentNode.getName(), Toast.LENGTH_SHORT).show();
                        btn1.setText(nodeName);
                        n += 1;
                        btn1.setId(n);
                        buttonText = btn1.getText().toString();
                        btn1.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                Button b = (Button) view;
                                String buttonText = b.getText().toString();
                                if (deletePressed == true) {
                                    Toast.makeText(PicTree.this, ":(", Toast.LENGTH_SHORT).show();
                                    deleteNode(buttonText);
                                    ViewGroup layout = (ViewGroup) btn1.getParent();
                                    if (null != layout)
                                        layout.removeView(btn1);
                                } else {

                                    String search = b.getText().toString();
                                    parentNode = root.recursiveSearch(search, root);
                                    Toast.makeText(PicTree.this, parentNode.getName(), Toast.LENGTH_SHORT).show();
                                    showLevel(newNode);
                                }
                            }
                        });
                        layoutTree.addView(btn1);

                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        Button goToDecision= (Button) findViewById(R.id.cameraBtn);
        goToDecision.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if(parentNode == null)
                {
                    showLevel(root);
                    parentNode=root;
                }
                else if(parentNode!= root)
                {
                    showLevel(parentNode.getParent());
                    parentNode=parentNode.getParent();
                    Toast.makeText(PicTree.this, parentNode.getName(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        Button deleteBtn= (Button) findViewById(R.id.deleteBtn);
        deleteBtn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                Toast.makeText(context,"Select the Node to Delete", Toast.LENGTH_SHORT).show();
                deletePressed=true;
            }
        });

        Button saveBtn= (Button) findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    serializeTree(root, "serializable.ser")	;
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        });

        Button loadTreeBtn= (Button) findViewById(R.id.loadTreeBtn);
        loadTreeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view)
            {
                if(parentNode==null)
                {
                    showLevel(root);
                }
                else
                {
                    showLevel(parentNode);
                }
                showLevel(root);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {

        MenuInflater blowUp = getMenuInflater();
        blowUp.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.pref:
                Intent p = new Intent (PicTree.this, Preferences.class);
                startActivity(p);
                break;

            case R.id.info:
                Intent inf = new Intent(PicTree.this, Information.class);
                startActivity(inf);
                break;
            case R.id.exit:
                finish();
                break;
        }
        return false;
    }

    public void serializeTree(Node root, String fileName) throws IOException
    {
        if (root == null) return;
        FileOutputStream fOut = openFileOutput(fileName, Context.MODE_PRIVATE);
        ObjectOutputStream outS = new ObjectOutputStream(fOut);
        outS.writeObject(root);
        outS.close();
        fOut.close();
    }

    public Node deSerializeTree(String fileName) throws IOException, ClassNotFoundException
    {
        if(fileExistence(fileName)==true)
        {
            FileInputStream inS = openFileInput(fileName);
            ObjectInputStream is = new ObjectInputStream(inS);

            @SuppressWarnings("unchecked")
            Node root =(Node) is.readObject();
            is.close();
            inS.close();
            return root;
        }
        else return null;
    }

    public void deleteNode(String nodeName
    ){
        Node node=root.recursiveSearch(nodeName,root);
        Node parent=node.getParent();
        parent.removeChild(node);
        Toast.makeText(PicTree.this,node.getName() + "- Deleted", Toast.LENGTH_SHORT).show();
        deletePressed=false;
    }

    public boolean fileExistence(String fileName)
    {
        File f = getBaseContext().getFileStreamPath(fileName);
        return f.exists();
    }

    public void showLevel(final Node node)
    {
        final LinearLayout layoutTree = (LinearLayout) findViewById(R.id.treeLayout);
        layoutTree.removeAllViews();
        if(node!=null &&node.children()!=null){
            for(final Node node1:node.children())
            {
                if(node1!=null)
                {
                    final Button button1 = new Button(context);
                    button1.setText(node1.getName());
                    layoutTree.addView(button1);
                    button1.setOnClickListener(new View.OnClickListener()
                    {
                        public void onClick(View view) {
                            if(deletePressed==true)
                            {
                                deleteNode(node1.getName());
                                ViewGroup layout = (ViewGroup) button1.getParent();
                                if(null!=layout)
                                    layout.removeView(button1);
                            }
                            else
                            {
                                parentNode=node1;
                                showLevel(node1);
                            }
                        }
                    });


                }
            }
        }
        else
        {
            parentNode=node;
            layoutTree.removeAllViews();
        }
    }
}
    /*
	public static void main(String[] args) throws Exception
	{
		Node root = new Node("Start", null);

		Node solid = new Node ("Solid", root);
		root.addChild(solid);

		Node flexible = new Node ("Flexible", root);
		root.addChild(flexible);

        Node filamentous = new Node ("Filamentous", flexible);
        solid.addChild(filamentous);    //A slender or threadlike structure

		Node hard = new Node ("Hard", solid);
		solid.addChild(hard);

		Node squashed = new Node ("Can be squashed", solid);
		//squashed.setImage(new ImageIcon("me.png"));	//DCIM/photos/.....
		solid.addChild(squashed);

		//Save the tree......
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("tree.ser"));

		out.writeObject(root);
		out.flush();
		out.close();

		//Load the tree
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(new File("tree.ser")));

		root = (Node) in.readObject();
		System.out.println(root.getName());
	}*/





