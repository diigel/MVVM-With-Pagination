package com.digel.spkproject;


import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Calendar;


public class MainActivity extends ActionBarActivity implements LocationListener
{
    private static String logtag = "Android Decision Support System";
    private static int TAKE_PIC = 1;
    private Uri imageURI;
    protected TextView person;
    protected TextView vessel;
    protected TextView lat;
    protected TextView longit;
    public static File _file;
    public static File _dir;
    public static Bitmap bitmap;
    LocationManager locationManager;

    /*private class StateSaver
    {
        private boolean showSplashScreen = true;
        // Other save state info here...
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vessel = (TextView) findViewById(R.id.textViewName);
        person = (TextView) findViewById(R.id.textViewVessel);
        lat =(TextView) findViewById(R.id.textViewLat);
        longit = (TextView) findViewById(R.id.textViewLong);

        showUserPreferences();

        ImageButton cameraButton = (ImageButton) findViewById(R.id.button_camera);
        // set a listener on the button
        cameraButton.setOnClickListener(cameraListener);

        ImageButton treeButton = (ImageButton)findViewById(R.id.button_List);
        // set a listener on the button
        treeButton.setOnClickListener(treePageListener);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if(location != null && location.getTime() > Calendar.getInstance().getTimeInMillis() - 2 * 60 * 1000)
        {
            lat.setText("Latitude: " + String.valueOf(location.getLatitude()+ " "));
            longit.setText("Longitude: " + String.valueOf(location.getLongitude()+ " "));
        }
        else
        {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        }
    }

    private OnClickListener cameraListener = new OnClickListener()
    {
        public void onClick(View v) {
            takePhoto(v);
        }
    };

    private View.OnClickListener treePageListener = new View.OnClickListener() {
        public void onClick(View v)
        {
            Intent intent = new Intent(MainActivity.this, PicTree.class);
            startActivity(intent);
        }
    };

    public void takePhoto(View v) {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        File photo = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "pic.jpg");
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photo));
        imageURI = Uri.fromFile(photo);
        startActivityForResult(intent, TAKE_PIC);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       /* // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;*/
        MenuInflater blowUp = getMenuInflater();
        blowUp.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode)
        {
            case 1:
                if(resultCode == Activity.RESULT_OK) {
                    Uri selectedImage = imageURI;
                    getContentResolver().notifyChange(selectedImage, null);
                    ImageView imageView = (ImageView)findViewById(R.id.image_V_camera);
                    ContentResolver cr = getContentResolver();
                    Bitmap bitmap;
                    try {
                        bitmap = android.provider.MediaStore.Images.Media.getBitmap(cr, selectedImage);
                        imageView.setImageBitmap(bitmap);
                        Toast.makeText(MainActivity.this, selectedImage.toString(), Toast.LENGTH_LONG).show();
                    } catch(Exception e) {
                        Toast.makeText(MainActivity.this, "failed to load", Toast.LENGTH_LONG).show();
                        Log.e(logtag, e.toString());
                    }

                }
        }
    }

    private void showUserPreferences()
    {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        StringBuilder sBuilder = new StringBuilder();
        sBuilder.append("Name: " + sharedPref.getString("person" , " "));
        sBuilder.append("\nVessel: " + sharedPref.getString("vessel"," "));

        vessel.setText(sBuilder.toString());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.pref:
                Intent p = new Intent (MainActivity.this, Preferences.class);
                startActivity(p);
                break;

            case R.id.info:
                Intent inf = new Intent(MainActivity.this, Information.class);
                startActivity(inf);
                break;
            case R.id.exit:
                finish();
                break;
        }
        return false;
    }

    @Override
    public void onLocationChanged(Location location)
    {
        if (location != null) {
            Log.v("Location Changed", location.getLatitude() + " and " + location.getLongitude());
            locationManager.removeUpdates(this);
        }
        lat.setText("Latitude: " + String.valueOf(location.getLatitude()+ " "));
        longit.setText("Longitude: " + String.valueOf(location.getLongitude()+ " "));
        location.getLatitude();
        location.getLongitude();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
